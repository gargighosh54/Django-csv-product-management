from django.shortcuts import render
from django.http import HttpRequest,HttpResponse
from django.conf import settings
import os
import pandas as pd

def upload_file(request:HttpRequest) -> HttpResponse:
    context = {}

    if request.method == "POST" and request.FILES.get("file"):
        name = request.POST.get ('name')
        age = request.POST.get('age')
        email = request.POST.get('email')
        phone_no = request.POST.get("phone_no")
        address = request.POST.get("address")
        uploaded_file = request.FILES["file"]

        file_path = os.path.join(settings.MEDIA_ROOT, uploaded_file.name)   

        with open(file_path, 'wb+') as destination:    # wb+ = write binary files .since the file cointaining multiople bites, we cant copy and paste in one go.
            for chunk in uploaded_file.chunks():       #we haqve to repeat this process so thjat all bite save successfully.
                destination.write(chunk)
                # file_path= which file we need to write. destination= entire thing refers to destination . chuncks= write the file in to the chuncks.

        try:
            df: pd.DataFrame = pd.read_csv(file_path) #read the csv. df variable name   Python by itself doesn't automatically give us a convenient table-processing system. Pandas gives that.

            #save information in to session
            request.session['csv_file'] = uploaded_file.name
            request.session['name'] = name
            request.session['age'] = age
            request.session['email'] = email
            request.session['phone_no'] = phone_no
            request.session['address'] = address

            #send data to html
            context['success'] = True # here success is like a flag.A flag is simply a value that tells the template  whether something happened successfully or not.
            #The CSV upload and reading process was successful. success gives the HTML information about the state
            context['name'] = name
            context['age'] = age
            context['email'] = email
            context['phone_no'] = phone_no
            context['address'] =address
            context['file_name'] = uploaded_file.name
            context['table'] = df.to_html(classes='table table-striped table-bordered', index=True)    # to_html= it converts the pandas data to html dom element in tabular format so we can see. true is for indexing.
            context['describe'] = df.describe()

        except Exception as e:
            context['error'] = f'Error reading csv file :{e}'


    elif request.method == "GET":
        file_name = request.session.get('csv_file')          # session is storing the name,age these data which we input by our own .

        if file_name:
            file_path = os.path.join(settings.MEDIA_ROOT, file_name)

            try:
                df = pd.read_csv(file_path)
                context['success'] = True
                context['name'] = request.session.get('name')
                context['age'] = request.session.get('age')
                context['email'] = request.session.get('email')
                context['phone_no'] = request.session.get('phone_no')
                context['address'] =request.session.get('address')
                context['file_name'] = file_name
                context['table'] = df.to_html(classes='table table-striped table-bordered', index=True)
                context['describe'] = df.describe()

            except Exception as e:
                context["error"] = f'Error reading csv file :{e}'

    return render(request,'product/home.html', context)


def search_page(request: HttpRequest) -> HttpResponse:
    return render(request, 'product/search.html')


def search_file(request: HttpRequest) -> HttpResponse:
    context = {}

    if request.method == 'POST':
        search_column = request.POST.get('search_column')
        search_value = request.POST.get('search_value')
        file_name = request.session.get('csv_file')

        if not file_name:
            context['error'] = 'Please upload a CSV file first.'
            return render(request, 'product/search.html', context)

        file_path = os.path.join(settings.MEDIA_ROOT, file_name)

        try:
            df = pd.read_csv(file_path)

            if search_column not in df.columns:
                context['error'] = f"Column '{search_column}' does not exist in the CSV file."
                return render(request, 'product/search.html', context)

            result = df.loc[df[search_column].astype(str).str.contains(search_value, case=False, na=False)]

            context['success'] = True
            context['search_column'] = search_column
            context['search_value'] = search_value
            context['file_name'] = file_name
            context['result'] = result.to_html(classes='table table-striped table-bordered', index=True)

        except Exception as e:
            context['error'] = f"Error searching CSV file: {e}"

    return render(request, 'product/search.html', context)


