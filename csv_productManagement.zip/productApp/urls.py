
from django.contrib import admin
from django.urls import path
from .views import upload_file,  search_page, search_file

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', upload_file, name='upload_file'),
    path('search/', search_page, name='search_page'),
    path('search-file/', search_file, name='search_file'),
]
